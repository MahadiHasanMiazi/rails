Rails.application.routes.draw do
  devise_for :users
  resources :organizations
  # resource :home
  # get 'home/index'
  # root 'pages#home'

  get '/team/member', to: 'home#index'
  get '/login', to: 'home#login'
  post '/login', to: 'home#postLogin'
  get '/details/:id', to: 'home#show', :as => :member
  get '/edit/:id', to: 'home#edit', :as => :member_edit
  post '/edit/:id', to: 'home#update'
  delete '/delete/:id', to: 'home#delete', :as => :member_delete
  get '/', to: 'teams#index', :as => :team
  get '/add/team', to: 'teams#new', :as => :add_team
  post '/add/team', to: 'teams#create'
  get '/members/:name', to: 'teams#allMember', :as => :all_member
  get '/members/:name/add/member', to: 'home#getAddMember', :as => :add_member
  post '/members/:name/add/member', to: 'home#postAddMember'
  get '/logout', to: 'home#logout', :as => :logout

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
