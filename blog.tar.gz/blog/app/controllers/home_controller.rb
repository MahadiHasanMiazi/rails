class HomeController < ApplicationController
  def index
    if session[:organization_id]
      @memberList = Member.where(organization_id: session[:organization_id])
    end

  end
  def show
    if session[:organization_id]
      @member = Member.find(params[:id])
    end
  end
  def edit
    @memberInfo = Member.find(params[:id])
  end
  def update
    member_edited = Member.find(params[:id])
    if member_edited.update(update_params)
      redirect_to '/'
    else
      redirect_to :back, :notice => "Can not update!"
    end

  end
  def delete
    member_delete = Member.find(params[:id])
    if member_delete.destroy
      redirect_to '/'
    else
      redirect_to '/', :notice => "can not deleted"
    end
  end

  def login

  end

  def postLogin
    organization = Organization.find_by(email:login_params[:username])
    if organization
      if organization.email == login_params[:username] && organization.password == login_params[:password]
        session[:organization_id] = organization.id
        redirect_to '/'
      else
        redirect_to login_path(), :notice => " Wrong username or Password"
      end
    else
      redirect_to login_path(), :notice => "User does not exist"
    end
  end

  def getAddMember

  end
  def postAddMember
    team = Team.where(organization_id: session[:organization_id]).where(name: params[:name]).first()
    @teamId = team.id
    member = Member.new(member_params)
    if member.save()
      redirect_to '/'
    else
      redirect_to add_member_path(), :notice => "Member can not save!"
    end
  end
  def logout
    session[:organization_id] = nil
    redirect_to '/login'
  end

  private
      def login_params
        params.permit(:username, :password)
      end

      def member_params
        params.require(:add).permit(:name, :email, :age).merge(organization_id: session[:organization_id], team_id: @teamId)
      end
      def update_params
        params.require(:edit).permit(:name, :email, :age)
      end
end
