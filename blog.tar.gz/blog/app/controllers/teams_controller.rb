class TeamsController < ApplicationController
  def index
    if before_action :authenticate_organization!
      @teams = Team.where(organization_id: session[:organization_id])
    else
      redirect_to '/login'
    end

  end
  def new
    if session[:organization_id]

    else
      redirect_to "/login"
    end
  end
  def create
    team = Team.new(team_params)
    if team.save()
      redirect_to '/'
    else
      redirect_to '/add/team', :notice => 'can not save!'
    end
  end
  def allMember
    if session[:organization_id]
      @team= Team.where(organization_id: session[:organization_id]).where(name: params[:name]).first()
      @id = @team.id
      @member = Member.where(organization_id: session[:organization_id]).where(team_id: @id)
      if @member

      end
    end

    # redirect_to 'team/member'
  end

  private
  def team_params
    params.require(:addTeam).permit(:name).merge(organization_id: session[:organization_id])
  end
end
