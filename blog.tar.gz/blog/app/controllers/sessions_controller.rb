class SessionsController < ApplicationController
  def login

  end
end
