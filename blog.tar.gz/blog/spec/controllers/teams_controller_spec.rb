require 'rails_helper'

RSpec.describe TeamsController, type: :controller do

end
