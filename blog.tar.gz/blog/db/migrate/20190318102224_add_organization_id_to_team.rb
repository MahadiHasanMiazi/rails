class AddOrganizationIdToTeam < ActiveRecord::Migration[5.2]
  def change
    add_column :teams, :organization_id, :integer
  end
end
